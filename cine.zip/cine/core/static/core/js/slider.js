
$(".slider").bxSlider({
    mode:'fade',
    auto:true,
    pause:3000,
    captions:true
});

//horizontal
//vertical
//fade